# ✦ Safar — Agent-Based Budget-Constrained Explainable Travel Planning System

> Final Year Project | Python + Flask + SQLite + Optional LLM (Anthropic Claude)

---

## 📁 Project Structure

```
travel_planner/
├── backend/
│   ├── app.py                        ← Flask app factory + entry point
│   ├── config.py                     ← All configuration settings
│   ├── requirements.txt              ← Python dependencies
│   ├── sample_data.json              ← Seed data (cities + places)
│   ├── db_utils.py                   ← Database utility CLI
│   │
│   ├── models/
│   │   ├── __init__.py
│   │   ├── database.py               ← SQLAlchemy instance
│   │   ├── city.py                   ← City model (cities table)
│   │   └── place.py                  ← Place model (places table)
│   │
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── chat.py                   ← /api/chat/message endpoint
│   │   └── itinerary.py              ← /api/itinerary/cities + places
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── intent_classifier.py      ← Rule-based intent detection
│   │   ├── entity_extractor.py       ← Budget/days/city extraction
│   │   ├── planning_engine.py        ← ⚠️ CORE: Rule-based itinerary generator
│   │   └── explanation_generator.py  ← LLM explanation layer (optional)
│   │
│   ├── utils/
│   │   ├── __init__.py
│   │   └── session_store.py          ← In-memory conversation state
│   │
│   └── tests/
│       └── test_services.py          ← Unit tests
│
└── frontend/
    ├── templates/
    │   └── index.html                ← Main chat UI
    └── static/
        ├── css/
        │   └── style.css             ← All styles (pastel theme)
        └── js/
            └── app.js                ← Chat logic + rendering
```

---

## 🚀 Quick Start

### 1. Install dependencies

```bash
cd travel_planner/backend
pip install -r requirements.txt
```

### 2. (Optional) Enable AI explanations

```bash
export ANTHROPIC_API_KEY="your-api-key-here"
```
> Skip this step to use built-in template explanations — the planner works fully without it.

### 3. Run the application

```bash
cd travel_planner/backend
python app.py
```

The app auto-seeds the database on first run. Open: **http://localhost:5000**

---

## 🧠 Architecture: Two-Brain System

```
User Message
     │
     ▼
Intent Classifier ──────► GREETING / SET_* intents
     │                     → conversational reply
     │
     ▼
Entity Extractor
     │
     ▼
Session Store (update)
     │
     ▼
  PLAN_REQUEST?
     │
     ├─ Missing fields? → Ask user
     │
     └─ All fields set?
          │
          ▼
   ┌─────────────────────────┐
   │  BRAIN 1: Planning      │  ← Rule-based, deterministic
   │  Engine (rule-based)    │     Strictly enforces budget
   └─────────────────────────┘
          │
          ▼
   ┌─────────────────────────┐
   │  BRAIN 2: Explanation   │  ← LLM (optional)
   │  Generator (LLM only)   │     Explains decisions in natural language
   └─────────────────────────┘
          │
          ▼
   Response → Frontend
```

---

## ⚙️ Core Planning Algorithm

The planning engine (`services/planning_engine.py`) uses this rule-based logic:

```
1. budget_per_person = total_budget / num_people

2. hotel_tier = pick_tier(HOTEL_TIERS, budget_per_person)
   food_tier  = pick_tier(FOOD_TIERS, budget_per_person)

3. fixed_costs = hotel_cost + food_cost + transport_cost

4. activity_budget = total_budget - fixed_costs

5. places = filter_by_city(city)
            → filter(cost <= activity_budget)
            → sort(rating DESC, cost ASC)
            → prioritize preferred categories

6. For each day:
   → greedily assign places
   → enforce: activity_budget_spent + place.cost ≤ activity_budget
   → enforce: daily_hours + place.time_required ≤ 8h
   → enforce: places_per_day ≤ MAX_PLACES_PER_DAY (4)

7. Return itinerary + budget_breakdown
```

**The LLM is never consulted during planning. All decisions are rule-based.**

---

## 🗄️ Database Schema

### Table: `cities`
| Column | Type    | Notes                      |
|--------|---------|----------------------------|
| id     | INTEGER | Primary key, auto-increment|
| name   | STRING  | City name, unique          |

### Table: `places`
| Column        | Type    | Notes                                           |
|---------------|---------|-------------------------------------------------|
| id            | INTEGER | Primary key                                     |
| name          | STRING  | Place name                                      |
| city_id       | INTEGER | FK → cities.id                                  |
| category      | STRING  | historical / food / nature / shopping           |
| cost          | INTEGER | Entry cost in PKR (0 = free)                    |
| popularity    | STRING  | famous / hidden                                 |
| description   | TEXT    | Short description                               |
| rating        | FLOAT   | 0.0 – 5.0 (optional)                           |
| time_required | INTEGER | Estimated hours needed                          |
| best_time     | STRING  | Morning / Afternoon / Evening                   |

---

## 🔌 API Reference

### POST `/api/chat/message`
Main conversational endpoint.

**Request:**
```json
{
  "message": "Plan a trip to Lahore for 2 days, 2 people, budget 20000",
  "session_id": "optional-uuid"
}
```

**Response:**
```json
{
  "reply": "Your 2-day trip to Lahore has been planned...",
  "intent": "PLAN_REQUEST",
  "session_id": "abc-123",
  "itinerary": {
    "success": true,
    "city": "Lahore",
    "budget_breakdown": { ... },
    "days": [ { "day": 1, "places": [ ... ] } ],
    "warnings": [],
    "ai_explanation": "..."
  }
}
```

### POST `/api/chat/reset`
Clear session and start over.

### GET `/api/itinerary/cities`
List all available cities.

### GET `/api/itinerary/places?city_id=1&category=historical&max_cost=500`
List places with optional filters.

---

## 🧪 Running Tests

```bash
cd travel_planner/backend
python -m pytest tests/ -v
```

---

## 🛠️ Database Utilities

```bash
# Re-seed from sample_data.json
python db_utils.py seed

# Export current data to JSON
python db_utils.py export

# Reset database (drop + recreate)
python db_utils.py reset

# Print schema
python db_utils.py schema
```

---

## 🔧 Configuration (`config.py`)

| Setting                | Default | Description                       |
|------------------------|---------|-----------------------------------|
| `HOTEL_BUDGET_RATIO`   | 0.45    | Hotel % of total budget           |
| `FOOD_BUDGET_RATIO`    | 0.30    | Food % of total budget            |
| `MAX_PLACES_PER_DAY`   | 4       | Max attractions per day           |
| `ANTHROPIC_API_KEY`    | ""      | Set for LLM explanations          |

---

## 📦 Switching to PostgreSQL

1. Install `psycopg2`:
   ```bash
   pip install psycopg2-binary
   ```

2. Set environment variable:
   ```bash
   export DATABASE_URL="postgresql://user:password@localhost/travel_planner"
   ```

3. The SQLAlchemy models work identically with PostgreSQL.

---

## 💡 Chat Examples

```
"My budget is 15000 for 2 days in Lahore for 2 people"
"Plan a 3-day trip to Islamabad for 1 person with a budget of 20000"
"Budget is 25000 for 2 people for 2 days in Murree"
"I prefer nature spots"
"Why was this place chosen?"
"Plan my trip"
```

---

## 🎓 Project Info

- **Title:** Agent-Based Budget-Constrained Explainable Travel Planning System
- **Stack:** Python 3.11+ · Flask 3.0 · SQLAlchemy · SQLite/PostgreSQL · Anthropic Claude (optional)
- **Key principle:** Rule-based planning + AI explanation = transparent, trustworthy recommendations
