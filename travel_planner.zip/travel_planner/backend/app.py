"""
Travel Planner - Main Flask Application
Entry point for the backend server
"""

from flask import Flask
from flask_cors import CORS
from models.database import db
from routes.chat import chat_bp
from routes.itinerary import itinerary_bp
from config import Config


def create_app(config_class=Config):
    """Application factory pattern for clean initialization."""
    app = Flask(__name__, template_folder="../frontend/templates", static_folder="../frontend/static")
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    CORS(app)

    # Register blueprints
    app.register_blueprint(chat_bp, url_prefix="/api/chat")
    app.register_blueprint(itinerary_bp, url_prefix="/api/itinerary")

    # Serve frontend
    from flask import render_template

    @app.route("/")
    def index():
        return render_template("index.html")

    # Create tables if they don't exist
    with app.app_context():
        db.create_all()
        _seed_sample_data()

    return app


def _seed_sample_data():
    """Seed the database with sample travel data for Pakistan cities."""
    from models.city import City
    from models.place import Place

    if City.query.count() > 0:
        return  # Already seeded

    # ── Cities ──
    lahore = City(name="Lahore")
    islamabad = City(name="Islamabad")
    murree = City(name="Murree")
    db.session.add_all([lahore, islamabad, murree])
    db.session.flush()

    # ── Places ──
    places = [
        # Lahore
        Place(name="Badshahi Mosque", city_id=lahore.id, category="historical", cost=0, popularity="famous",
              description="One of the world's largest mosques, a Mughal masterpiece built in 1673.", rating=4.9,
              time_required=2, best_time="Morning"),
        Place(name="Lahore Fort (Shahi Qila)", city_id=lahore.id, category="historical", cost=500, popularity="famous",
              description="UNESCO World Heritage Site showcasing Mughal architecture over 1,000 years.", rating=4.8,
              time_required=3, best_time="Morning"),
        Place(name="Shalimar Gardens", city_id=lahore.id, category="nature", cost=300, popularity="famous",
              description="Magnificent Mughal terraced gardens with fountains and marble pavilions.", rating=4.6,
              time_required=2, best_time="Evening"),
        Place(name="Food Street Gawalmandi", city_id=lahore.id, category="food", cost=800, popularity="famous",
              description="Iconic food street famous for traditional Lahori cuisine and street food.", rating=4.7,
              time_required=2, best_time="Evening"),
        Place(name="Wazir Khan Mosque", city_id=lahore.id, category="historical", cost=0, popularity="hidden",
              description="Hidden gem with stunning tilework — less crowded than Badshahi Mosque.", rating=4.8,
              time_required=1, best_time="Morning"),
        Place(name="Anarkali Bazaar", city_id=lahore.id, category="shopping", cost=500, popularity="famous",
              description="Pakistan's oldest surviving bazaar with traditional handicrafts and textiles.", rating=4.4,
              time_required=2, best_time="Afternoon"),
        Place(name="Lahore Museum", city_id=lahore.id, category="historical", cost=200, popularity="famous",
              description="Largest museum in Pakistan housing Gandhara sculptures and Mughal artifacts.", rating=4.5,
              time_required=2, best_time="Morning"),
        Place(name="Chauburji", city_id=lahore.id, category="historical", cost=0, popularity="hidden",
              description="Underrated 17th-century Mughal gateway with intricate tilework.", rating=4.3,
              time_required=1, best_time="Morning"),

        # Islamabad
        Place(name="Faisal Mosque", city_id=islamabad.id, category="historical", cost=0, popularity="famous",
              description="One of the largest mosques in the world, nestled against the Margalla Hills.", rating=4.9,
              time_required=2, best_time="Morning"),
        Place(name="Margalla Hills Trail 3", city_id=islamabad.id, category="nature", cost=0, popularity="famous",
              description="Most popular hiking trail offering panoramic views of Islamabad city.", rating=4.7,
              time_required=3, best_time="Morning"),
        Place(name="Pakistan Monument", city_id=islamabad.id, category="historical", cost=100, popularity="famous",
              description="National monument shaped like a blossoming flower representing Pakistan's four provinces.", rating=4.6,
              time_required=1, best_time="Evening"),
        Place(name="Lok Virsa Museum", city_id=islamabad.id, category="historical", cost=200, popularity="hidden",
              description="Fascinating folk heritage museum showcasing Pakistan's diverse cultural traditions.", rating=4.5,
              time_required=2, best_time="Morning"),
        Place(name="Rawal Lake", city_id=islamabad.id, category="nature", cost=0, popularity="famous",
              description="Scenic reservoir with boating, bird watching, and serene walking paths.", rating=4.4,
              time_required=2, best_time="Afternoon"),
        Place(name="Daman-e-Koh", city_id=islamabad.id, category="nature", cost=0, popularity="famous",
              description="Hilltop viewpoint offering breathtaking views of Islamabad and surroundings.", rating=4.8,
              time_required=2, best_time="Evening"),
        Place(name="Saidpur Village", city_id=islamabad.id, category="historical", cost=300, popularity="hidden",
              description="Ancient village turned arts village with galleries, cafes, and heritage homes.", rating=4.5,
              time_required=2, best_time="Afternoon"),
        Place(name="F-9 Park (Fatima Jinnah Park)", city_id=islamabad.id, category="nature", cost=0, popularity="famous",
              description="Largest park in Islamabad — perfect for families and evening walks.", rating=4.3,
              time_required=1, best_time="Evening"),

        # Murree
        Place(name="Mall Road Murree", city_id=murree.id, category="shopping", cost=500, popularity="famous",
              description="Main tourist street with shops, cafes, and iconic cable car access.", rating=4.5,
              time_required=2, best_time="Afternoon"),
        Place(name="Pindi Point", city_id=murree.id, category="nature", cost=200, popularity="famous",
              description="Famous viewpoint and chairlift with panoramic views of the Himalayan foothills.", rating=4.6,
              time_required=2, best_time="Morning"),
        Place(name="Kashmir Point", city_id=murree.id, category="nature", cost=0, popularity="famous",
              description="Stunning viewpoint offering views across valleys and pine forests.", rating=4.7,
              time_required=1, best_time="Morning"),
        Place(name="Bhurban Village", city_id=murree.id, category="nature", cost=0, popularity="hidden",
              description="Quiet, lush pine forest village — a peaceful escape from busy Murree.", rating=4.6,
              time_required=2, best_time="Morning"),
        Place(name="GPO Chowk", city_id=murree.id, category="historical", cost=0, popularity="famous",
              description="Historic central square with colonial-era architecture and local food stalls.", rating=4.2,
              time_required=1, best_time="Evening"),
        Place(name="Patriata (New Murree)", city_id=murree.id, category="nature", cost=400, popularity="famous",
              description="Pine-forested hill station with chairlift rides and scenic forest walks.", rating=4.5,
              time_required=3, best_time="Morning"),
        Place(name="Nathiagali", city_id=murree.id, category="nature", cost=0, popularity="hidden",
              description="Hidden gem with dense forests and trails rarely visited by tourists.", rating=4.8,
              time_required=3, best_time="Morning"),
    ]
    db.session.add_all(places)
    db.session.commit()
    print("✅ Sample data seeded successfully.")


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5000)
