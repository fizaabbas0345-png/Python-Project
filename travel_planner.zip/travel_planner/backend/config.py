"""
Configuration settings for the Travel Planner application.
Modify OPENAI_API_KEY or ANTHROPIC_API_KEY to enable LLM explanations.
"""

import os


class Config:
    # Flask secret key
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-travel-planner-2024")

    # Database — SQLite for development, PostgreSQL for production
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        "sqlite:///travel_planner.db"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # LLM Configuration (optional — used ONLY for explanation text)
    # Set via environment variable: export ANTHROPIC_API_KEY="your-key"
    ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

    # Budget allocation percentages (tunable)
    HOTEL_BUDGET_RATIO = 0.45    # 45% of total budget for accommodation
    FOOD_BUDGET_RATIO = 0.30     # 30% of total budget for food
    ACTIVITY_BUDGET_RATIO = 0.25 # 25% of total budget for activities/entry fees

    # Hotel cost per night per person (PKR) — rough estimates
    HOTEL_COST_BUDGET = 2000
    HOTEL_COST_STANDARD = 4000
    HOTEL_COST_PREMIUM = 7000

    # Food cost per day per person (PKR) — rough estimates
    FOOD_COST_BUDGET = 500
    FOOD_COST_STANDARD = 1000
    FOOD_COST_PREMIUM = 2000

    # Max places per day
    MAX_PLACES_PER_DAY = 4

    # Debug mode
    DEBUG = os.environ.get("FLASK_DEBUG", "True") == "True"
