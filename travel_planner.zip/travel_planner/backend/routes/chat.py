"""
Chat Route
──────────
Handles the main conversational endpoint.
Orchestrates: intent → entity extraction → session update → planning → explanation
"""

import uuid
from flask import Blueprint, request, jsonify, session

from services.intent_classifier import classify_intent
from services.entity_extractor import extract_all_entities
from services.planning_engine import generate_itinerary
from services.explanation_generator import generate_explanation, generate_conversational_reply
from utils.session_store import (
    get_session, update_session, get_missing_fields,
    store_itinerary, get_last_itinerary
)

chat_bp = Blueprint("chat", __name__)


@chat_bp.route("/message", methods=["POST"])
def handle_message():
    """
    Main chat endpoint.

    Request body:
        { "message": "Plan my trip", "session_id": "abc123" }

    Response:
        {
            "reply": "Here is your plan...",
            "intent": "PLAN_REQUEST",
            "itinerary": { ... } | null,
            "session_id": "abc123"
        }
    """
    data = request.get_json()
    if not data or "message" not in data:
        return jsonify({"error": "Missing 'message' in request body"}), 400

    user_message = data.get("message", "").strip()
    session_id = data.get("session_id") or str(uuid.uuid4())

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    # ── Step 1: Classify intent ───────────────────────────────────────────────
    intent = classify_intent(user_message)

    # ── Step 2: Extract entities ──────────────────────────────────────────────
    entities = extract_all_entities(user_message)

    # ── Step 3: Update session state ──────────────────────────────────────────
    update_session(session_id, entities)
    ctx = get_session(session_id)

    # ── Step 4: Route by intent ───────────────────────────────────────────────

    # Handle explanation request
    if intent == "EXPLANATION_REQUEST":
        last = get_last_itinerary(session_id)
        if last:
            explanation_text = generate_explanation(last, ctx)
            return jsonify({
                "reply": explanation_text,
                "intent": intent,
                "itinerary": None,
                "session_id": session_id,
            })
        else:
            return jsonify({
                "reply": "I don't have a plan to explain yet! Say 'plan my trip' first, and then ask me to explain it.",
                "intent": intent,
                "itinerary": None,
                "session_id": session_id,
            })

    # Handle plan request
    if intent == "PLAN_REQUEST":
        missing = get_missing_fields(session_id)

        if missing:
            reply = generate_conversational_reply("UNKNOWN", missing, ctx)
            return jsonify({
                "reply": reply,
                "intent": "NEEDS_INFO",
                "itinerary": None,
                "session_id": session_id,
            })

        # All fields present — run the planning engine
        result = generate_itinerary(
            budget=ctx["budget"],
            days=ctx["days"],
            people=ctx["people"],
            city=ctx["city"],
            preferences=ctx.get("preferences", []),
        )

        if not result["success"]:
            return jsonify({
                "reply": f"Sorry, I couldn't generate a plan: {result['error']}",
                "intent": intent,
                "itinerary": None,
                "session_id": session_id,
            })

        # Store itinerary for potential follow-up explanation
        store_itinerary(session_id, result)

        # Generate LLM explanation of the plan
        explanation = generate_explanation(result, ctx)
        result["ai_explanation"] = explanation

        return jsonify({
            "reply": explanation,
            "intent": intent,
            "itinerary": result,
            "session_id": session_id,
        })

    # Handle all other intents (constraint setting, greeting, etc.)
    missing = get_missing_fields(session_id)
    reply = generate_conversational_reply(intent, missing, ctx)

    return jsonify({
        "reply": reply,
        "intent": intent,
        "itinerary": None,
        "session_id": session_id,
    })


@chat_bp.route("/reset", methods=["POST"])
def reset_session():
    """Clear session state to start a new plan."""
    from utils.session_store import clear_session
    data = request.get_json() or {}
    session_id = data.get("session_id", "")
    if session_id:
        clear_session(session_id)
    return jsonify({"message": "Session cleared.", "session_id": session_id})
