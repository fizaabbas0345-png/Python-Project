"""
Entity Extractor Service
────────────────────────
Extracts structured entities from raw user messages using regex patterns.

Extracted entities:
    - budget   : integer (PKR amount)
    - days     : integer (number of days)
    - people   : integer (number of travelers)
    - city     : string ("Lahore" | "Islamabad" | "Murree")
    - preferences : list of strings (categories the user prefers)
"""

import re
from typing import Optional


# ── Known cities ─────────────────────────────────────────────────────────────

CITY_ALIASES = {
    "lahore": "Lahore",
    "islamabad": "Islamabad",
    "isb": "Islamabad",
    "murree": "Murree",
}

# ── Category preferences ─────────────────────────────────────────────────────

PREFERENCE_MAP = {
    "nature": "nature",
    "historical": "historical",
    "history": "historical",
    "heritage": "historical",
    "food": "food",
    "restaurant": "food",
    "eat": "food",
    "eating": "food",
    "shopping": "shopping",
    "bazaar": "shopping",
    "market": "shopping",
    "hidden": "hidden",
    "hidden gem": "hidden",
    "adventure": "nature",
    "culture": "historical",
    "sightseeing": "historical",
}


# ── Extraction functions ──────────────────────────────────────────────────────

def extract_budget(text: str) -> Optional[int]:
    """
    Extract a budget amount (PKR) from text.

    Handles formats:
        "50000", "50,000", "50k", "50 thousand",
        "budget is 50000", "rs 50000", "pkr 50000"
    """
    text_lower = text.lower()

    # Pattern: number followed by 'k' (e.g., "50k", "50 k")
    match = re.search(r"(\d+)\s*k\b", text_lower)
    if match:
        return int(match.group(1)) * 1000

    # Pattern: number followed by "thousand"
    match = re.search(r"(\d+)\s*thousand", text_lower)
    if match:
        return int(match.group(1)) * 1000

    # Pattern: plain number (with optional commas)
    # Only match if 3+ digits (to avoid matching "2 days" → 2)
    match = re.search(r"\b(\d{3,6})\b", text_lower.replace(",", ""))
    if match:
        value = int(match.group(1))
        if 500 <= value <= 999999:  # Sanity range for PKR budget
            return value

    return None


def extract_days(text: str) -> Optional[int]:
    """
    Extract number of days from text.

    Handles:
        "3 days", "2 nights", "a week", "for 4 days"
    """
    text_lower = text.lower()

    # "a week" or "one week"
    if "a week" in text_lower or "one week" in text_lower:
        return 7

    # Number + days/nights
    match = re.search(r"(\d+)\s*(?:day|days|night|nights)", text_lower)
    if match:
        return int(match.group(1))

    return None


def extract_people(text: str) -> Optional[int]:
    """
    Extract number of travelers from text.

    Handles:
        "2 people", "3 persons", "a family of 4", "just me", "just 1"
    """
    text_lower = text.lower()

    # "just me" or "only me" → 1
    if re.search(r"\b(just|only)?\s*me\b", text_lower):
        return 1

    # "family of 4", "group of 3"
    match = re.search(r"(?:family|group)\s+of\s+(\d+)", text_lower)
    if match:
        return int(match.group(1))

    # Number + people/person/persons/adults
    match = re.search(r"(\d+)\s*(?:people|person|persons|adults?|travelers?|of us|members?)", text_lower)
    if match:
        return int(match.group(1))

    # "we are 3" / "there are 4 of us"
    match = re.search(r"(?:we are|there are)\s+(\d+)", text_lower)
    if match:
        return int(match.group(1))

    return None


def extract_city(text: str) -> Optional[str]:
    """Extract destination city from text."""
    text_lower = text.lower()
    for alias, canonical in CITY_ALIASES.items():
        if alias in text_lower:
            return canonical
    return None


def extract_preferences(text: str) -> list:
    """Extract a list of place-category preferences from text."""
    text_lower = text.lower()
    prefs = []
    for keyword, category in PREFERENCE_MAP.items():
        if keyword in text_lower and category not in prefs:
            prefs.append(category)
    return prefs


def extract_all_entities(message: str) -> dict:
    """
    Run all extractors and return a unified entities dict.

    Returns:
        {
            "budget": int | None,
            "days": int | None,
            "people": int | None,
            "city": str | None,
            "preferences": list
        }
    """
    return {
        "budget": extract_budget(message),
        "days": extract_days(message),
        "people": extract_people(message),
        "city": extract_city(message),
        "preferences": extract_preferences(message),
    }
