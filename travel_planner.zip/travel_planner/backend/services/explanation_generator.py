"""
Explanation Generator Service
──────────────────────────────
Uses an LLM (via Anthropic API) ONLY to generate natural-language explanations
for itineraries that were already decided by the rule-based planning engine.

The LLM receives the finalized plan and explains it — it does NOT change it.
Falls back to rule-based template text if no API key is configured.
"""

import json
from flask import current_app


def _build_prompt(itinerary: dict, user_context: dict) -> str:
    """Build the explanation prompt from the finalized itinerary."""
    budget = itinerary["budget_breakdown"]
    days_text = []
    for day in itinerary["days"]:
        places = [p["name"] for p in day["places"]]
        days_text.append(f"Day {day['day']}: {', '.join(places) if places else 'Rest day / travel'}")

    prompt = f"""You are a helpful travel assistant explaining a pre-generated travel itinerary.

The itinerary was created by a rule-based system that strictly enforced a budget of Rs {budget['total_budget']:,} 
for {budget['people']} person(s) over {budget['days']} days in {itinerary['city']}.

Budget breakdown:
- Accommodation: {budget['hotel']['label']} — Rs {budget['hotel']['total_cost']:,}
- Food: {budget['food']['label']} — Rs {budget['food']['total_cost']:,}  
- Transport: Rs {budget['transport']['total_cost']:,}
- Activities: Rs {budget['activities']['spent']:,} (of Rs {budget['activities']['allocated']:,} allocated)
- Leftover: Rs {budget['leftover']:,}

Itinerary:
{chr(10).join(days_text)}

Write a warm, friendly 3-4 sentence explanation of this itinerary plan. Mention:
1. Why this breakdown makes sense for the budget
2. What makes the selected city/places good value
3. One practical travel tip for this trip

Keep it conversational, encouraging, and under 120 words. Do NOT suggest changes."""

    return prompt


def _fallback_explanation(itinerary: dict) -> str:
    """Template-based explanation when LLM is not configured."""
    budget = itinerary["budget_breakdown"]
    city = itinerary["city"]
    total_places = itinerary.get("total_places", 0)

    return (
        f"Your {budget['days']}-day trip to {city} for {budget['people']} person(s) "
        f"has been carefully planned within your Rs {budget['total_budget']:,} budget. "
        f"The plan includes {total_places} carefully selected attractions, "
        f"with Rs {budget['hotel']['total_cost']:,} allocated for a {budget['hotel']['label'].lower()}, "
        f"Rs {budget['food']['total_cost']:,} for meals ({budget['food']['label'].lower()}), "
        f"and Rs {budget['transport']['total_cost']:,} for local transport. "
        f"You'll have Rs {budget['leftover']:,} left over as a safety buffer. "
        f"Every place was selected by our rule-based engine to maximize your experience within budget!"
    )


def generate_explanation(itinerary: dict, user_context: dict) -> str:
    """
    Generate a natural-language explanation for the given itinerary.

    Tries Anthropic Claude API first; falls back to template text.
    The LLM ONLY explains — it does not modify the plan.
    """
    api_key = current_app.config.get("ANTHROPIC_API_KEY", "")

    if not api_key:
        return _fallback_explanation(itinerary)

    try:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)

        prompt = _build_prompt(itinerary, user_context)

        message = client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text.strip()

    except Exception as e:
        current_app.logger.warning(f"LLM explanation failed: {e}. Using fallback.")
        return _fallback_explanation(itinerary)


def generate_conversational_reply(intent: str, missing_fields: list, user_context: dict) -> str:
    """
    Generate a natural conversational response when we need more information
    or when acknowledging a constraint update.

    This is template-based (no LLM) for reliability.
    """
    city = user_context.get("city", "your destination")
    budget = user_context.get("budget")
    days = user_context.get("days")
    people = user_context.get("people")

    if intent == "GREETING":
        return (
            "Hello! I'm your AI travel planner. I can help you plan a budget-friendly "
            "trip to Lahore, Islamabad, or Murree. Just tell me your budget, how many days "
            "you're travelling, the number of people, and your destination — and I'll create "
            "a complete day-by-day itinerary!"
        )

    if intent == "SET_BUDGET" and budget:
        return f"Got it! I've noted your budget of Rs {budget:,}. Now, which city would you like to visit — Lahore, Islamabad, or Murree?"

    if intent == "SET_CITY" and city != "your destination":
        return f"Great choice! {city} is wonderful. How many days are you planning to stay, and how many people will be travelling?"

    if intent == "SET_DAYS" and days:
        msg = f"Perfect — {days} days noted!"
        if not people:
            msg += " How many people will be travelling?"
        return msg

    if intent == "SET_PEOPLE" and people:
        return f"Great, planning for {people} person(s). " + (
            "Now just tell me your budget and I'll get started!" if not budget else
            f"You have a budget of Rs {budget:,}. Ready to generate your plan! Just say 'plan my trip'."
        )

    if missing_fields:
        field_prompts = {
            "budget": "your total budget in PKR",
            "city": "which city you want to visit (Lahore, Islamabad, or Murree)",
            "days": "how many days you'll be travelling",
            "people": "how many people are travelling",
        }
        missing_text = " and ".join(field_prompts.get(f, f) for f in missing_fields[:2])
        return f"I just need a few more details — could you tell me {missing_text}?"

    return (
        "I'm not sure I understood that. You can tell me your budget, destination, "
        "number of days, or say 'plan my trip' to generate your itinerary!"
    )
