"""
Intent Classifier Service
─────────────────────────
Rule-based sentence classifier that detects user intent from chat messages.

Intents:
    - SET_BUDGET       : user is specifying budget
    - SET_DAYS         : user is specifying number of days
    - SET_PEOPLE       : user is specifying number of people
    - SET_CITY         : user is specifying destination
    - SET_PREFERENCE   : user is specifying preferences (nature, food, etc.)
    - PLAN_REQUEST     : user wants to generate an itinerary
    - EXPLANATION_REQUEST : user wants to know why something was chosen
    - GREETING         : general greeting
    - UNKNOWN          : unrecognized input
"""

import re


# ── Keyword sets per intent ──────────────────────────────────────────────────

PLAN_KEYWORDS = [
    "plan", "generate", "create", "make", "build", "give me",
    "itinerary", "trip", "schedule", "suggest", "recommend",
    "travel plan", "day plan", "show me", "book", "organize"
]

EXPLANATION_KEYWORDS = [
    "why", "explain", "reason", "because", "how did you", "how come",
    "what's the reason", "tell me why", "justify", "elaborate",
    "why this", "why these", "why did you"
]

BUDGET_KEYWORDS = [
    "budget", "money", "spend", "cost", "afford", "rs", "pkr",
    "rupees", "rupee", "thousand", "k budget", "price"
]

DAYS_KEYWORDS = [
    "day", "days", "night", "nights", "week", "duration",
    "how long", "trip length"
]

PEOPLE_KEYWORDS = [
    "people", "persons", "person", "adult", "adults",
    "family", "friends", "group", "traveler", "travelers",
    "of us", "members"
]

CITY_KEYWORDS = ["lahore", "islamabad", "murree"]

PREFERENCE_KEYWORDS = [
    "prefer", "like", "love", "interested", "enjoy", "nature",
    "historical", "food", "shopping", "hidden", "adventure",
    "culture", "sightseeing"
]

GREETING_KEYWORDS = [
    "hello", "hi", "hey", "good morning", "good afternoon",
    "good evening", "greetings", "salaam", "assalam"
]


# ── Classifier ───────────────────────────────────────────────────────────────

def classify_intent(message: str) -> str:
    """
    Classify the user's intent from their message text.

    Returns one of the INTENT constants defined above.
    Priority order matters — check plan/explain before general keywords.
    """
    text = message.lower().strip()

    # 1. Plan request (highest priority — often contains budget/day words too)
    if any(kw in text for kw in PLAN_KEYWORDS):
        return "PLAN_REQUEST"

    # 2. Explanation request
    if any(kw in text for kw in EXPLANATION_KEYWORDS):
        return "EXPLANATION_REQUEST"

    # 3. Greeting
    if any(kw in text for kw in GREETING_KEYWORDS):
        return "GREETING"

    # 4. Budget setting
    if any(kw in text for kw in BUDGET_KEYWORDS):
        return "SET_BUDGET"

    # 5. Days setting
    if any(kw in text for kw in DAYS_KEYWORDS):
        return "SET_DAYS"

    # 6. People setting
    if any(kw in text for kw in PEOPLE_KEYWORDS):
        return "SET_PEOPLE"

    # 7. City selection
    if any(kw in text for kw in CITY_KEYWORDS):
        return "SET_CITY"

    # 8. Preference
    if any(kw in text for kw in PREFERENCE_KEYWORDS):
        return "SET_PREFERENCE"

    return "UNKNOWN"
