"""
Planning Engine Service
───────────────────────
RULE-BASED itinerary generator. No AI/LLM involved in any planning decision.

Algorithm:
    1. Calculate per-person budget
    2. Determine hotel tier based on budget
    3. Subtract fixed hotel + food costs from total
    4. Remaining budget = activity budget
    5. Filter places by city, then sort by rating DESC, cost ASC
    6. Greedily assign places to days within activity budget
    7. Return structured itinerary with cost breakdown

All decisions are deterministic and explainable by rules.
"""

from flask import current_app
from models.place import Place
from models.city import City
from typing import Optional


# ── Hotel tiers (PKR per person per night) ────────────────────────────────────

HOTEL_TIERS = [
    {"label": "Budget guesthouse",  "cost_per_person_night": 1500,  "min_budget_per_person": 0},
    {"label": "Standard hotel",     "cost_per_person_night": 3500,  "min_budget_per_person": 8000},
    {"label": "Comfortable hotel",  "cost_per_person_night": 6000,  "min_budget_per_person": 15000},
    {"label": "Premium hotel",      "cost_per_person_night": 10000, "min_budget_per_person": 25000},
]

# ── Food tiers (PKR per person per day) ───────────────────────────────────────

FOOD_TIERS = [
    {"label": "Street food / dhabas",  "cost_per_person_day": 400,  "min_budget_per_person": 0},
    {"label": "Local restaurants",     "cost_per_person_day": 800,  "min_budget_per_person": 8000},
    {"label": "Mid-range restaurants", "cost_per_person_day": 1500, "min_budget_per_person": 15000},
    {"label": "Fine dining",           "cost_per_person_day": 3000, "min_budget_per_person": 25000},
]

# ── Transport cost (flat estimate per person per day) ─────────────────────────

TRANSPORT_COST_PER_PERSON_DAY = 500


def _pick_tier(tiers: list, budget_per_person: float) -> dict:
    """Pick the highest affordable tier for a given budget."""
    selected = tiers[0]
    for tier in tiers:
        if budget_per_person >= tier["min_budget_per_person"]:
            selected = tier
    return selected


def _get_city(city_name: str) -> Optional[City]:
    """Fetch city object by name (case-insensitive)."""
    return City.query.filter(City.name.ilike(city_name)).first()


def _filter_and_sort_places(city_id: int, preferences: list, available_budget: float) -> list:
    """
    Filter places by city and optionally by preference categories.
    Sort by: preference match → rating DESC → cost ASC.

    Only includes places that fit within the available_budget.
    """
    query = Place.query.filter_by(city_id=city_id)

    # If preferences given, prioritize matching categories
    if preferences:
        preferred = query.filter(Place.category.in_(preferences)).all()
        other = query.filter(~Place.category.in_(preferences)).all()
        all_places = preferred + other
    else:
        all_places = query.all()

    # Filter to affordable places
    affordable = [p for p in all_places if p.cost <= available_budget]

    # Sort: rating DESC (None → 0), then cost ASC
    affordable.sort(key=lambda p: (-(p.rating or 0), p.cost))
    return affordable


def _explain_place_selection(place, activity_budget_remaining, preferences):
    """
    Generate a rule-based explanation string for why this place was selected.
    This is the RULE LAYER of explanation (not AI).
    """
    reasons = []

    if place.cost == 0:
        reasons.append("it is completely free to visit")
    elif place.cost < 300:
        reasons.append(f"it has a low entry cost of Rs {place.cost}")

    if place.rating and place.rating >= 4.5:
        reasons.append(f"it has an excellent visitor rating of {place.rating}/5")
    elif place.rating and place.rating >= 4.0:
        reasons.append(f"it is highly rated at {place.rating}/5")

    if preferences and place.category in preferences:
        reasons.append(f"it matches your preference for {place.category} experiences")

    if place.popularity == "hidden":
        reasons.append("it is an off-the-beaten-path hidden gem")

    if not reasons:
        reasons.append("it fits within your available activity budget")

    return "Selected because " + ", and ".join(reasons) + "."


def generate_itinerary(budget: int, days: int, people: int, city: str, preferences: list = None) -> dict:
    """
    Main planning function. Generates a day-wise itinerary using rule-based logic.

    Args:
        budget       : Total trip budget in PKR
        days         : Number of travel days
        people       : Number of travelers
        city         : Destination city name
        preferences  : List of preferred categories

    Returns:
        {
            "success": bool,
            "error": str | None,
            "city": str,
            "budget_breakdown": {...},
            "days": [ { "day": int, "places": [...] } ],
            "warnings": [...]
        }
    """
    preferences = preferences or []
    warnings = []

    # ── 1. Fetch city ──────────────────────────────────────────────────────────
    city_obj = _get_city(city)
    if not city_obj:
        return {"success": False, "error": f"City '{city}' not found in database."}

    # ── 2. Per-person budget ───────────────────────────────────────────────────
    budget_per_person = budget / people

    # ── 3. Select hotel and food tiers ────────────────────────────────────────
    hotel_tier = _pick_tier(HOTEL_TIERS, budget_per_person)
    food_tier = _pick_tier(FOOD_TIERS, budget_per_person)

    hotel_cost_total = hotel_tier["cost_per_person_night"] * people * days
    food_cost_total = food_tier["cost_per_person_day"] * people * days
    transport_cost_total = TRANSPORT_COST_PER_PERSON_DAY * people * days

    fixed_costs = hotel_cost_total + food_cost_total + transport_cost_total
    activity_budget = budget - fixed_costs

    # ── 4. Sanity check ────────────────────────────────────────────────────────
    if activity_budget < 0:
        # Budget too tight — reduce hotel tier by 1 if possible
        warnings.append(
            f"Budget is tight. Reduced hotel to '{HOTEL_TIERS[0]['label']}' to fit all costs."
        )
        hotel_tier = HOTEL_TIERS[0]
        hotel_cost_total = hotel_tier["cost_per_person_night"] * people * days
        fixed_costs = hotel_cost_total + food_cost_total + transport_cost_total
        activity_budget = budget - fixed_costs

    if activity_budget < 0:
        activity_budget = 0
        warnings.append("Activity budget is exhausted. Only free places will be included.")

    # ── 5. Get sorted, affordable places ──────────────────────────────────────
    max_places_per_day = current_app.config.get("MAX_PLACES_PER_DAY", 4)
    places_pool = _filter_and_sort_places(city_obj.id, preferences, activity_budget)

    if not places_pool:
        return {
            "success": False,
            "error": "No places found for this city and budget. Try increasing your budget or adjusting preferences."
        }

    # ── 6. Greedy day-by-day assignment ───────────────────────────────────────
    activity_spent = 0.0
    days_plan = []
    used_place_ids = set()

    for day_num in range(1, days + 1):
        day_places = []
        day_budget_used = 0
        daily_hours = 0
        max_hours_per_day = 8  # Realistic daily limit

        for place in places_pool:
            # Skip already-used places
            if place.id in used_place_ids:
                continue

            # Skip if this place would bust the remaining activity budget
            if activity_spent + place.cost > activity_budget:
                continue

            # Skip if this place would exceed daily time
            if daily_hours + place.time_required > max_hours_per_day:
                continue

            # Skip if we've hit max places per day
            if len(day_places) >= max_places_per_day:
                break

            # ✅ Place qualifies — add to this day
            explanation = _explain_place_selection(
                place, activity_budget - activity_spent, preferences
            )
            day_places.append({
                **place.to_dict(),
                "explanation": explanation,
            })
            used_place_ids.add(place.id)
            activity_spent += place.cost
            day_budget_used += place.cost
            daily_hours += place.time_required

        days_plan.append({
            "day": day_num,
            "places": day_places,
            "day_activity_cost": day_budget_used,
            "day_hours": daily_hours,
        })

    # ── 7. Final budget breakdown ──────────────────────────────────────────────
    total_spent = fixed_costs + activity_spent
    leftover = budget - total_spent

    budget_breakdown = {
        "total_budget": budget,
        "people": people,
        "days": days,
        "hotel": {
            "label": hotel_tier["label"],
            "total_cost": hotel_cost_total,
            "per_person_per_night": hotel_tier["cost_per_person_night"],
        },
        "food": {
            "label": food_tier["label"],
            "total_cost": food_cost_total,
            "per_person_per_day": food_tier["cost_per_person_day"],
        },
        "transport": {
            "total_cost": transport_cost_total,
            "per_person_per_day": TRANSPORT_COST_PER_PERSON_DAY,
        },
        "activities": {
            "allocated": activity_budget,
            "spent": activity_spent,
        },
        "total_spent": total_spent,
        "leftover": max(0, leftover),
    }

    return {
        "success": True,
        "error": None,
        "city": city_obj.name,
        "budget_breakdown": budget_breakdown,
        "days": days_plan,
        "warnings": warnings,
        "total_places": len(used_place_ids),
    }
