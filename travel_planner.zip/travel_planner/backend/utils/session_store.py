"""
Session Store Utility
─────────────────────
In-memory session store for managing user conversation state.
In production, replace with Redis or a database-backed session.

Each session tracks:
    - budget, days, people, city, preferences (user constraints)
    - last_itinerary (most recent plan, for explanation requests)
    - history (list of messages for display)
"""

from typing import Optional

# In-memory store: { session_id: { ...user_data } }
_sessions: dict = {}


def get_session(session_id: str) -> dict:
    """Retrieve or create a session context."""
    if session_id not in _sessions:
        _sessions[session_id] = {
            "budget": None,
            "days": None,
            "people": None,
            "city": None,
            "preferences": [],
            "last_itinerary": None,
        }
    return _sessions[session_id]


def update_session(session_id: str, updates: dict):
    """Merge extracted entities into the session context."""
    session = get_session(session_id)
    for key, value in updates.items():
        if value is not None:
            # For preferences, extend the list (don't overwrite)
            if key == "preferences" and isinstance(value, list):
                existing = session.get("preferences", [])
                merged = list(set(existing + value))
                session["preferences"] = merged
            else:
                session[key] = value


def get_missing_fields(session_id: str) -> list:
    """Return a list of required fields that haven't been set yet."""
    session = get_session(session_id)
    missing = []
    for field in ["budget", "days", "people", "city"]:
        if not session.get(field):
            missing.append(field)
    return missing


def clear_session(session_id: str):
    """Reset a session (e.g., when user wants to start over)."""
    if session_id in _sessions:
        del _sessions[session_id]


def store_itinerary(session_id: str, itinerary: dict):
    """Store the most recently generated itinerary for later explanation requests."""
    session = get_session(session_id)
    session["last_itinerary"] = itinerary


def get_last_itinerary(session_id: str) -> Optional[dict]:
    """Retrieve the last generated itinerary for this session."""
    session = get_session(session_id)
    return session.get("last_itinerary")
