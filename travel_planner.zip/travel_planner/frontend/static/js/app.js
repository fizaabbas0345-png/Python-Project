/**
 * Safar — Travel Planner Frontend
 * Handles: chat UI, API calls, itinerary rendering, budget charts
 */

// ── State ──────────────────────────────────────────────────────────────────

const state = {
  sessionId: null,
  lastItinerary: null,
};

// ── DOM References ─────────────────────────────────────────────────────────

const chatWindow    = document.getElementById('chatWindow');
const chatInput     = document.getElementById('chatInput');
const sendBtn       = document.getElementById('sendBtn');
const menuBtn       = document.getElementById('menuBtn');
const sidebar       = document.getElementById('sidebar');
const sidebarClose  = document.getElementById('sidebarClose');
const resetBtn      = document.getElementById('resetBtn');
const navBtns       = document.querySelectorAll('.nav-btn');
const panels        = document.querySelectorAll('.panel');

// ── Sidebar & Navigation ───────────────────────────────────────────────────

function openSidebar() {
  sidebar.classList.add('open');
  // overlay
  let overlay = document.querySelector('.sidebar-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.addEventListener('click', closeSidebar);
    document.body.appendChild(overlay);
  }
  overlay.classList.add('active');
}

function closeSidebar() {
  sidebar.classList.remove('open');
  const overlay = document.querySelector('.sidebar-overlay');
  if (overlay) overlay.classList.remove('active');
}

menuBtn.addEventListener('click', openSidebar);
sidebarClose.addEventListener('click', closeSidebar);

navBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.dataset.panel;
    navBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    panels.forEach(p => p.classList.remove('active'));
    document.getElementById('panel' + capitalize(target)).classList.add('active');
    if (window.innerWidth <= 768) closeSidebar();
  });
});

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function switchToPanel(name) {
  navBtns.forEach(b => {
    b.classList.toggle('active', b.dataset.panel === name.toLowerCase());
  });
  panels.forEach(p => p.classList.remove('active'));
  document.getElementById('panel' + capitalize(name)).classList.add('active');
}

// ── Reset ──────────────────────────────────────────────────────────────────

resetBtn.addEventListener('click', async () => {
  if (state.sessionId) {
    try {
      await fetch('/api/chat/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: state.sessionId }),
      });
    } catch (_) {}
  }
  state.sessionId = null;
  state.lastItinerary = null;

  // Clear chat (keep welcome)
  const msgs = chatWindow.querySelectorAll('.msg:not(#welcomeMsg)');
  msgs.forEach(m => m.remove());
  // Restore hint chips
  document.querySelector('.quick-hints')?.style.removeProperty('display');

  // Clear panels
  document.getElementById('itineraryContent').innerHTML = emptyState('🗺️', 'Your itinerary will appear here once you generate a plan in the chat.');
  document.getElementById('budgetContent').innerHTML = emptyState('📊', 'Budget details will appear here after your plan is generated.');

  // Reset context pills
  updateContextPills({});
  switchToPanel('chat');
});

// ── Send message ───────────────────────────────────────────────────────────

async function sendMessage(text) {
  const msg = text ?? chatInput.value.trim();
  if (!msg) return;

  chatInput.value = '';
  resizeChatInput();

  // Hide welcome hint chips after first message
  const hints = document.querySelector('.quick-hints');
  if (hints) hints.style.display = 'none';

  appendMessage(msg, 'user');
  sendBtn.disabled = true;

  const typingId = appendTypingIndicator();

  try {
    const response = await fetch('/api/chat/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, session_id: state.sessionId }),
    });

    removeTypingIndicator(typingId);

    if (!response.ok) {
      throw new Error(`Server error: ${response.status}`);
    }

    const data = await response.json();
    state.sessionId = data.session_id;

    appendMessage(data.reply, 'bot');

    if (data.itinerary) {
      state.lastItinerary = data.itinerary;
      renderItinerary(data.itinerary);
      renderBudget(data.itinerary);
      updateContextPills(data.itinerary);

      // Auto-switch to itinerary panel
      setTimeout(() => switchToPanel('itinerary'), 1200);
    }

  } catch (err) {
    removeTypingIndicator(typingId);
    appendMessage('Sorry, I encountered an error. Please try again.', 'bot');
    console.error('Chat error:', err);
  } finally {
    sendBtn.disabled = false;
    chatInput.focus();
  }
}

// Public hint function (called from HTML onclick)
window.sendHint = function(text) {
  sendMessage(text);
};

// ── Input handling ─────────────────────────────────────────────────────────

chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

sendBtn.addEventListener('click', () => sendMessage());

chatInput.addEventListener('input', resizeChatInput);

function resizeChatInput() {
  chatInput.style.height = 'auto';
  chatInput.style.height = Math.min(chatInput.scrollHeight, 130) + 'px';
}

// ── Chat message rendering ─────────────────────────────────────────────────

function appendMessage(text, role) {
  const wrapper = document.createElement('div');
  wrapper.className = `msg msg-${role}`;

  if (role === 'bot') {
    wrapper.innerHTML = `
      <div class="msg-avatar">✦</div>
      <div class="msg-bubble">${formatMessage(text)}</div>
    `;
  } else {
    wrapper.innerHTML = `
      <div class="msg-bubble">${escapeHtml(text)}</div>
    `;
  }

  chatWindow.appendChild(wrapper);
  scrollChatToBottom();
  return wrapper;
}

function appendTypingIndicator() {
  const id = 'typing-' + Date.now();
  const wrapper = document.createElement('div');
  wrapper.className = 'msg msg-bot';
  wrapper.id = id;
  wrapper.innerHTML = `
    <div class="msg-avatar">✦</div>
    <div class="typing-bubble">
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
    </div>
  `;
  chatWindow.appendChild(wrapper);
  scrollChatToBottom();
  return id;
}

function removeTypingIndicator(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function scrollChatToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function formatMessage(text) {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>')
    .replace(/^/, '<p>')
    .replace(/$/, '</p>');
}

function escapeHtml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ── Itinerary rendering ────────────────────────────────────────────────────

function renderItinerary(itinerary) {
  const container = document.getElementById('itineraryContent');
  const { days, city, budget_breakdown, ai_explanation, warnings } = itinerary;

  let html = '';

  // AI explanation banner
  if (ai_explanation) {
    html += `
      <div class="ai-explanation-box">
        <div class="ai-label">✦ AI Summary</div>
        ${escapeHtml(ai_explanation)}
      </div>
    `;
  }

  // Warnings
  if (warnings && warnings.length > 0) {
    warnings.forEach(w => {
      html += `<div class="warning-box">⚠️ ${escapeHtml(w)}</div>`;
    });
  }

  // Day cards
  days.forEach((day, i) => {
    const delay = i * 80;
    const hasFree = day.places.filter(p => p.cost === 0).length;
    html += `
      <div class="day-card" style="animation-delay:${delay}ms">
        <div class="day-header">
          <span class="day-number">Day ${day.day}</span>
          <span class="day-meta">
            ${day.places.length} place${day.places.length !== 1 ? 's' : ''} ·
            ~${day.day_hours}h ·
            Activity budget: Rs ${fmtNum(day.day_activity_cost)}
          </span>
        </div>
    `;

    if (day.places.length === 0) {
      html += `<div class="place-item"><p style="color:var(--mid);font-size:14px">No places within budget for this day. Consider a rest day or travel day.</p></div>`;
    } else {
      day.places.forEach(place => {
        const costHtml = place.cost === 0
          ? `<span class="place-cost free">Free</span>`
          : `<span class="place-cost">Rs ${fmtNum(place.cost)}</span>`;

        const tags = [place.category, place.popularity === 'hidden' ? 'hidden gem' : null]
          .filter(Boolean)
          .map(t => `<span class="tag ${t.replace(' ', '-')}">${t}</span>`)
          .join('');

        const rating = place.rating
          ? `<span class="place-meta-item"><span class="rating-stars">★</span> ${place.rating}</span>`
          : '';
        const time = `<span class="place-meta-item">🕐 ~${place.time_required}h</span>`;
        const bestTime = place.best_time
          ? `<span class="place-meta-item">🌅 ${escapeHtml(place.best_time)}</span>`
          : '';

        html += `
          <div class="place-item">
            <div class="place-top">
              <span class="place-name">${escapeHtml(place.name)}</span>
              ${costHtml}
            </div>
            <div class="place-tags">${tags}</div>
            ${place.description ? `<p class="place-desc">${escapeHtml(place.description)}</p>` : ''}
            <div class="place-footer">${rating}${time}${bestTime}</div>
            ${place.explanation ? `<div class="place-explanation">${escapeHtml(place.explanation)}</div>` : ''}
          </div>
        `;
      });
    }

    html += `</div>`;
  });

  container.innerHTML = html;
}

// ── Budget rendering ───────────────────────────────────────────────────────

function renderBudget(itinerary) {
  const b = itinerary.budget_breakdown;
  const container = document.getElementById('budgetContent');

  const pct = v => Math.min(100, Math.round((v / b.total_budget) * 100));

  const bars = [
    { label: 'Accommodation', value: b.hotel.total_cost, color: '#C8DDF0', accent: '#6899C4' },
    { label: 'Food & Drinks', value: b.food.total_cost, color: '#C8D8C0', accent: '#8AAF80' },
    { label: 'Transport', value: b.transport.total_cost, color: '#D8D0F0', accent: '#7B6DAE' },
    { label: 'Activities', value: b.activities.spent, color: '#F2D5CB', accent: '#D4896A' },
  ];

  let html = `
    <div class="budget-summary">
      <div class="budget-card">
        <div class="budget-card-label">Total Budget</div>
        <div class="budget-card-value">Rs ${fmtNum(b.total_budget)}</div>
        <div class="budget-card-sub">${b.people} person${b.people > 1 ? 's' : ''}, ${b.days} day${b.days > 1 ? 's' : ''}</div>
      </div>
      <div class="budget-card">
        <div class="budget-card-label">Total Spent</div>
        <div class="budget-card-value">Rs ${fmtNum(b.total_spent)}</div>
        <div class="budget-card-sub">${pct(b.total_spent)}% of budget</div>
      </div>
      <div class="budget-card">
        <div class="budget-card-label">Leftover</div>
        <div class="budget-card-value" style="color:#2E7D4F">Rs ${fmtNum(b.leftover)}</div>
        <div class="budget-card-sub">Safety buffer</div>
      </div>
      <div class="budget-card">
        <div class="budget-card-label">Per Person/Day</div>
        <div class="budget-card-value">Rs ${fmtNum(Math.round(b.total_budget / b.people / b.days))}</div>
        <div class="budget-card-sub">Average daily cost</div>
      </div>
    </div>

    <div class="budget-bar-section">
  `;

  bars.forEach(bar => {
    const p = pct(bar.value);
    html += `
      <div style="margin-bottom:14px">
        <div class="budget-bar-label">
          <span>${bar.label}</span>
          <span>Rs ${fmtNum(bar.value)} (${p}%)</span>
        </div>
        <div class="budget-bar-track">
          <div class="budget-bar-fill"
               style="width:${p}%;background:${bar.accent};border-radius:999px">
          </div>
        </div>
      </div>
    `;
  });

  html += `</div>

    <table class="budget-table">
      <thead>
        <tr>
          <th>Category</th>
          <th>Details</th>
          <th style="text-align:right">Cost (Rs)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>🏨 Accommodation</td>
          <td>${escapeHtml(b.hotel.label)} — Rs ${fmtNum(b.hotel.per_person_per_night)}/person/night</td>
          <td style="text-align:right">${fmtNum(b.hotel.total_cost)}</td>
        </tr>
        <tr>
          <td>🍽️ Food</td>
          <td>${escapeHtml(b.food.label)} — Rs ${fmtNum(b.food.per_person_per_day)}/person/day</td>
          <td style="text-align:right">${fmtNum(b.food.total_cost)}</td>
        </tr>
        <tr>
          <td>🚌 Transport</td>
          <td>Rs ${fmtNum(b.transport.per_person_per_day)}/person/day (estimate)</td>
          <td style="text-align:right">${fmtNum(b.transport.total_cost)}</td>
        </tr>
        <tr>
          <td>🎯 Activities</td>
          <td>Rs ${fmtNum(b.activities.allocated)} allocated → Rs ${fmtNum(b.activities.spent)} used</td>
          <td style="text-align:right">${fmtNum(b.activities.spent)}</td>
        </tr>
        <tr class="budget-total">
          <td colspan="2"><strong>Total</strong></td>
          <td style="text-align:right"><strong>${fmtNum(b.total_spent)}</strong></td>
        </tr>
      </tbody>
    </table>
  `;

  container.innerHTML = html;
  // Animate bars
  setTimeout(() => {
    container.querySelectorAll('.budget-bar-fill').forEach(el => {
      const w = el.style.width;
      el.style.width = '0';
      requestAnimationFrame(() => { el.style.width = w; });
    });
  }, 80);
}

// ── Context pills ──────────────────────────────────────────────────────────

function updateContextPills(itinerary) {
  const b = itinerary.budget_breakdown;
  document.getElementById('ctxCity').textContent    = `🏙️ City: ${itinerary.city || '—'}`;
  document.getElementById('ctxBudget').textContent  = `💰 Budget: ${b ? 'Rs ' + fmtNum(b.total_budget) : '—'}`;
  document.getElementById('ctxDays').textContent    = `📅 Days: ${b ? b.days : '—'}`;
  document.getElementById('ctxPeople').textContent  = `👥 People: ${b ? b.people : '—'}`;
}

// ── Helpers ────────────────────────────────────────────────────────────────

function fmtNum(n) {
  return Math.round(n).toLocaleString('en-PK');
}

function emptyState(icon, text) {
  return `<div class="empty-state"><div class="empty-icon">${icon}</div><p>${text}</p></div>`;
}
